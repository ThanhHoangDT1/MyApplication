package com.androidexam.myapplication;

public interface IEvent {
    byte[] getBytes();

    void setSessionId(String sessionId);
}
